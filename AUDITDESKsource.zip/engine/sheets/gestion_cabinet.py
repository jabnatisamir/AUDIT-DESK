"""Generate the cabinet management sheets: time tracking, budget, billing, boni/mali."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_temps(wb, mission_data):
    ws = wb.create_sheet("Temps")
    ws.sheet_properties.tabColor = COLORS["gris_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 20
    for col_letter in "EFGHIJKLMNOP":
        ws.column_dimensions[col_letter].width = 10

    row = 2
    ws.merge_cells("B2:P2")
    cell = ws.cell(row=row, column=2, value="SAISIE DES TEMPS PAR INTERVENANT")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    write_section_title(ws, row, 2, "BUDGET D'HEURES", 10)
    row += 1
    budget_headers = ["Grade", "Heures budgetees", "Taux horaire", "Cout budgete"]
    for i, h in enumerate(budget_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    grades = ["Associe", "Manager", "Chef de mission", "Assistants"]
    for i, grade in enumerate(grades):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=grade).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        for col in [3, 4]:
            c = ws.cell(row=r, column=col, value=0)
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.number_format = '#,##0'
        c = ws.cell(row=r, column=5, value="")
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.number_format = '#,##0'

    r_total = row + 1 + len(grades)
    ws.cell(row=r_total, column=2, value="TOTAL").font = Font(name="Calibri", size=11, bold=True)
    ws.cell(row=r_total, column=2).border = THIN_BORDER
    for col in [3, 5]:
        c = ws.cell(row=r_total, column=col, value="")
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.font = Font(name="Calibri", size=11, bold=True)

    row = r_total + 3
    write_section_title(ws, row, 2, "SAISIE DES TEMPS", 16)
    row += 1

    months = ["Sept", "Oct", "Nov", "Dec", "Jan", "Fev", "Mars", "Avr", "Mai", "Juin", "Juil", "Total"]
    time_headers = ["Intervenant", "Grade"] + months
    for i, h in enumerate(time_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    for i in range(8):
        r = row + 1 + i
        ws.cell(row=r, column=2, value="").fill = fill_input()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=3, value="").fill = fill_input()
        ws.cell(row=r, column=3).border = THIN_BORDER
        for col in range(4, 15):
            c = ws.cell(row=r, column=col, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.number_format = '0.0'
        c = ws.cell(row=r, column=15, value="")
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.number_format = '0.0'

    r_total = row + 1 + 8
    ws.cell(row=r_total, column=2, value="TOTAL").font = Font(name="Calibri", size=11, bold=True)
    ws.cell(row=r_total, column=2).border = THIN_BORDER

    return ws


def create_rentabilite(wb, mission_data):
    ws = wb.create_sheet("Rentabilite")
    ws.sheet_properties.tabColor = COLORS["gris_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 35
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 18
    ws.column_dimensions["E"].width = 18
    ws.column_dimensions["F"].width = 35

    row = 2
    ws.merge_cells("B2:F2")
    cell = ws.cell(row=row, column=2, value="PILOTAGE ECONOMIQUE - BONI/MALI - RENTABILITE")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    write_section_title(ws, row, 2, "HONORAIRES", 6)
    row += 1
    hon_fields = [
        ("Honoraires budgetes (lettre de mission)", 0, True),
        ("Honoraires factures", 0, True),
        ("Ecart", "", False),
    ]
    for i, (label, default, is_input) in enumerate(hon_fields):
        r = row + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=3, value=default)
        c.fill = fill_input() if is_input else fill_calculated()
        c.border = THIN_BORDER
        c.number_format = '#,##0'

    row = row + len(hon_fields) + 1
    write_section_title(ws, row, 2, "TEMPS ET COUT DE REVIENT", 6)
    row += 1

    cost_headers = ["", "Budget", "Realise", "Ecart"]
    for i, h in enumerate(cost_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    cost_items = [
        "Heures associe",
        "Heures manager",
        "Heures chef de mission",
        "Heures assistants",
        "TOTAL HEURES",
        "",
        "Cout associe",
        "Cout manager",
        "Cout chef de mission",
        "Cout assistants",
        "TOTAL COUT DE REVIENT",
    ]

    for i, item in enumerate(cost_items):
        r = row + 1 + i
        cell_label = ws.cell(row=r, column=2, value=item)
        cell_label.border = THIN_BORDER
        if "TOTAL" in item:
            cell_label.font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
        else:
            cell_label.font = font_normal()

        for col in [3, 4]:
            c = ws.cell(row=r, column=col, value=0 if item else "")
            c.fill = fill_input() if item else PatternFill()
            c.border = THIN_BORDER if item else THIN_BORDER
            c.number_format = '#,##0'

        c = ws.cell(row=r, column=5, value="" if item else "")
        c.fill = fill_calculated() if item else PatternFill()
        c.border = THIN_BORDER if item else THIN_BORDER

    row = row + len(cost_items) + 2
    write_section_title(ws, row, 2, "BONI / MALI", 6)
    row += 1

    boni_fields = [
        ("Honoraires factures", "", False),
        ("Cout de revient total", "", False),
        ("BONI / MALI", "", False),
        ("Taux de marge", "", False),
    ]
    for i, (label, default, is_input) in enumerate(boni_fields):
        r = row + i
        ws.cell(row=r, column=2, value=label).font = Font(
            name="Calibri", size=11,
            bold=("BONI" in label or "Taux" in label),
            color=COLORS["bleu_fonce"]
        )
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=3, value=default)
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.number_format = '#,##0' if "Taux" not in label else '0.0%'

    row = row + len(boni_fields) + 1
    write_section_title(ws, row, 2, "COMMENTAIRES / ANALYSE", 6)
    row += 1
    ws.merge_cells(start_row=row, start_column=2, end_row=row + 3, end_column=6)
    c = ws.cell(row=row, column=2, value="[Analyser les ecarts et proposer des actions correctives]")
    c.fill = fill_input()
    c.border = THIN_BORDER
    c.alignment = align_wrap()

    return ws


def create_dashboard(wb, profil_code):
    ws = wb.create_sheet("Dashboard")
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 18
    ws.column_dimensions["E"].width = 18
    ws.column_dimensions["F"].width = 18

    row = 2
    ws.merge_cells("B2:F2")
    cell = ws.cell(row=row, column=2, value="TABLEAU DE BORD - AVANCEMENT MISSION")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:F3")
    cell = ws.cell(row=row, column=2, value="Compatible ISO 9001 / COPIL")
    cell.font = font_small()
    cell.alignment = align_center()

    row = 5
    write_section_title(ws, row, 2, "AVANCEMENT PAR MODULE", 6)
    row += 1

    dash_headers = ["Module", "% Avancement", "Statut", "Date prevue", "Date realisee"]
    for i, h in enumerate(dash_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_statut = DataValidation(
        type="list",
        formula1='"Non demarre,En cours,Termine,Revue,Valide,Cloture"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_statut)

    modules = [
        "Acceptation / maintien",
        "Prise de connaissance",
        "Seuils",
        "Planification",
        "Controle interne",
        "SI / ITGC / ITAC",
        "Matrice des risques",
        "Travaux par cycle",
        "Synthese des anomalies",
        "Synthese generale",
        "Evenements posterieurs",
        "Revue manager",
        "Revue associe",
        "Emission du rapport",
        "Archivage (60 jours)",
    ]

    for i, module in enumerate(modules):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=module).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        c_pct = ws.cell(row=r, column=3, value=0)
        c_pct.fill = fill_input()
        c_pct.border = THIN_BORDER
        c_pct.number_format = '0%'
        c_pct.alignment = align_center()

        c_stat = ws.cell(row=r, column=4, value="Non demarre")
        c_stat.fill = fill_input()
        c_stat.border = THIN_BORDER
        c_stat.alignment = align_center()
        dv_statut.add(c_stat)

        for col in [5, 6]:
            c = ws.cell(row=r, column=col, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER

    row = row + len(modules) + 2
    write_section_title(ws, row, 2, "INDICATEURS COPIL / ISO", 6)
    row += 1

    indicators = [
        ("Taux d'avancement global", "0%"),
        ("Nombre de points bloquants", "0"),
        ("Rapport emis", "Non"),
        ("Dossier archive", "Non"),
        ("Delai archivage respecte (60j)", "N/A"),
        ("Heures consommees / budget", "0%"),
        ("Boni/Mali previsionnel", "0"),
    ]

    for i, (label, default) in enumerate(indicators):
        r = row + i
        ws.cell(row=r, column=2, value=label).font = font_subheader()
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=3, value=default)
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
        c.alignment = align_center()

    return ws


# Fix missing import
from openpyxl.styles import PatternFill
