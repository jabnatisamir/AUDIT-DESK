"""Generate the Controle Interne / SI sheets."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from engine import data_loader
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_controle_interne(wb, profil_code):
    ws = wb.create_sheet("Controle Interne")
    ws.sheet_properties.tabColor = COLORS["orange"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 35
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 12
    ws.column_dimensions["G"].width = 35
    ws.column_dimensions["H"].width = 15
    ws.column_dimensions["I"].width = 35

    row = 2
    ws.merge_cells("B2:I2")
    cell = ws.cell(row=row, column=2, value="EVALUATION DU CONTROLE INTERNE")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:I3")
    cell = ws.cell(row=row, column=2,
                   value="NEP 315 - Prise de connaissance de l'entite et evaluation du controle interne")
    cell.font = font_small()
    cell.alignment = align_center()

    # --- Controles cles par cycle ---
    row = 5
    write_section_title(ws, row, 2, "CONTROLES CLES IDENTIFIES PAR CYCLE", 9)

    row += 1
    headers = ["Code", "Cycle", "Controle cle", "Type", "Frequence",
               "Evaluation conception", "Evaluation fonctionnement", "Incidence sur risque"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_eval = DataValidation(
        type="list",
        formula1='"Satisfaisant,A ameliorer,Insuffisant,Non evalue"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_eval)

    controles_data = data_loader.load_controles()
    controles = controles_data["controles_cles"]

    cycles_actifs = [c["code"] for c in data_loader.get_cycles_for_profil(profil_code)]
    controles_filtres = [c for c in controles if c["cycle"] in cycles_actifs]

    for i, ctrl in enumerate(controles_filtres):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=ctrl["code"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        cycle_nom = ctrl["cycle"]
        for cy in data_loader.load_cycles():
            if cy["code"] == ctrl["cycle"]:
                cycle_nom = cy["nom"]
                break
        ws.cell(row=r, column=3, value=cycle_nom).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER

        ws.cell(row=r, column=4, value=ctrl["intitule"]).font = font_normal()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=4).alignment = align_wrap()

        ws.cell(row=r, column=5, value=ctrl["type"]).font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=5).alignment = align_center()

        ws.cell(row=r, column=6, value=ctrl["frequence"]).font = font_normal()
        ws.cell(row=r, column=6).border = THIN_BORDER
        ws.cell(row=r, column=6).alignment = align_center()

        c_concept = ws.cell(row=r, column=7, value="Non evalue")
        c_concept.fill = fill_input()
        c_concept.border = THIN_BORDER
        c_concept.alignment = align_center()
        dv_eval.add(c_concept)

        c_fonct = ws.cell(row=r, column=8, value="Non evalue")
        c_fonct.fill = fill_input()
        c_fonct.border = THIN_BORDER
        c_fonct.alignment = align_center()
        dv_eval.add(c_fonct)

        c_incid = ws.cell(row=r, column=9, value="")
        c_incid.fill = fill_input()
        c_incid.border = THIN_BORDER
        c_incid.alignment = align_wrap()

    return ws


def create_itgc(wb):
    ws = wb.create_sheet("ITGC")
    ws.sheet_properties.tabColor = COLORS["orange"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 45
    ws.column_dimensions["E"].width = 15
    ws.column_dimensions["F"].width = 35
    ws.column_dimensions["G"].width = 35

    row = 2
    ws.merge_cells("B2:G2")
    cell = ws.cell(row=row, column=2, value="CONTROLES GENERAUX INFORMATIQUES (ITGC)")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:G3")
    cell = ws.cell(row=row, column=2,
                   value="Evaluation des controles generaux de l'environnement informatique")
    cell.font = font_small()
    cell.alignment = align_center()

    controles_data = data_loader.load_controles()
    itgcs = controles_data["itgc"]

    dv_eval = DataValidation(
        type="list",
        formula1='"Satisfaisant,A ameliorer,Insuffisant,Non applicable,Non evalue"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_eval)

    current_row = 5
    for itgc in itgcs:
        write_section_title(ws, current_row, 2, f"{itgc['code']} - {itgc['intitule']}", 7)
        current_row += 1

        ws.merge_cells(start_row=current_row, start_column=2, end_row=current_row, end_column=7)
        ws.cell(row=current_row, column=2, value=itgc["description"]).font = font_small()
        current_row += 1

        headers = ["#", "Question", "Reponse / Constats", "Evaluation", "Observations"]
        for i, h in enumerate(headers):
            c = ws.cell(row=current_row, column=2 + i, value=h)
            c.font = font_header()
            c.fill = fill_header()
            c.alignment = align_center()
            c.border = THIN_BORDER

        current_row += 1
        for j, question in enumerate(itgc["questions"]):
            ws.cell(row=current_row, column=2, value=j + 1).font = font_normal()
            ws.cell(row=current_row, column=2).border = THIN_BORDER
            ws.cell(row=current_row, column=2).alignment = align_center()

            ws.cell(row=current_row, column=3, value=question).font = font_normal()
            ws.cell(row=current_row, column=3).border = THIN_BORDER
            ws.cell(row=current_row, column=3).alignment = align_wrap()

            c_rep = ws.cell(row=current_row, column=4, value="")
            c_rep.fill = fill_input()
            c_rep.border = THIN_BORDER
            c_rep.alignment = align_wrap()

            c_eval = ws.cell(row=current_row, column=5, value="Non evalue")
            c_eval.fill = fill_input()
            c_eval.border = THIN_BORDER
            c_eval.alignment = align_center()
            dv_eval.add(c_eval)

            c_obs = ws.cell(row=current_row, column=6, value="")
            c_obs.fill = fill_input()
            c_obs.border = THIN_BORDER

            current_row += 1

        current_row += 1

    # Synthese ITGC
    write_section_title(ws, current_row, 2, "SYNTHESE ITGC", 7)
    current_row += 1

    synth_fields = [
        "Conclusion globale sur l'environnement informatique",
        "Points de faiblesse identifies",
        "Incidence sur la strategie d'audit",
        "Points a remonter en synthese",
    ]

    for label in synth_fields:
        ws.cell(row=current_row, column=2, value=label).font = font_subheader()
        ws.cell(row=current_row, column=2).border = THIN_BORDER
        ws.merge_cells(start_row=current_row, start_column=4, end_row=current_row, end_column=7)
        c = ws.cell(row=current_row, column=4, value="")
        c.fill = fill_input()
        c.border = THIN_BORDER
        c.alignment = align_wrap()
        current_row += 1

    return ws


def create_itac(wb):
    ws = wb.create_sheet("ITAC")
    ws.sheet_properties.tabColor = COLORS["orange"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 35
    ws.column_dimensions["D"].width = 45
    ws.column_dimensions["E"].width = 20
    ws.column_dimensions["F"].width = 15
    ws.column_dimensions["G"].width = 35

    row = 2
    ws.merge_cells("B2:G2")
    cell = ws.cell(row=row, column=2, value="CONTROLES AUTOMATISES APPLICATIFS (ITAC)")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    headers = ["Code", "Controle automatise", "Description",
               "Cycles concernes", "Evaluation", "Observations"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_eval = DataValidation(
        type="list",
        formula1='"Satisfaisant,A ameliorer,Insuffisant,Non applicable,Non evalue"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_eval)

    controles_data = data_loader.load_controles()
    itacs = controles_data["itac"]

    for i, itac in enumerate(itacs):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=itac["code"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        ws.cell(row=r, column=3, value=itac["intitule"]).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()

        exemples = "\n".join(f"- {e}" for e in itac["exemples"])
        ws.cell(row=r, column=4, value=exemples).font = font_small()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=4).alignment = align_wrap()

        cycles_str = ", ".join(itac["cycles_concernes"])
        ws.cell(row=r, column=5, value=cycles_str).font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=5).alignment = align_center()

        c_eval = ws.cell(row=r, column=6, value="Non evalue")
        c_eval.fill = fill_input()
        c_eval.border = THIN_BORDER
        c_eval.alignment = align_center()
        dv_eval.add(c_eval)

        c_obs = ws.cell(row=r, column=7, value="")
        c_obs.fill = fill_input()
        c_obs.border = THIN_BORDER

    return ws
