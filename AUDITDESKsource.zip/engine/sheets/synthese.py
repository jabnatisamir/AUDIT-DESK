"""Generate the synthesis, master sheets, anomalies, and finalization sheets."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    fill_risk, font_risk,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from engine import data_loader
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_feuilles_maitresses(wb, profil_code):
    ws = wb.create_sheet("Feuilles Maitresses")
    ws.sheet_properties.tabColor = COLORS["bleu_moyen"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 15
    ws.column_dimensions["C"].width = 30
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 15
    ws.column_dimensions["F"].width = 15
    ws.column_dimensions["G"].width = 15
    ws.column_dimensions["H"].width = 35
    ws.column_dimensions["I"].width = 12

    row = 2
    ws.merge_cells("B2:I2")
    cell = ws.cell(row=row, column=2, value="FEUILLES MAITRESSES - SYNTHESE PAR CYCLE")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:I3")
    cell = ws.cell(row=row, column=2,
                   value="Remontee automatique depuis les feuilles de travail par cycle")
    cell.font = font_small()
    cell.alignment = align_center()

    row = 5
    headers = ["Cycle", "Intitule", "Solde N", "Solde N-1",
               "Variation", "Variation %", "Conclusion du cycle", "Statut"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_statut = DataValidation(
        type="list",
        formula1='"Non demarre,En cours,Termine,Revue,Valide"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_statut)

    cycles = data_loader.get_cycles_for_profil(profil_code)
    for i, cycle in enumerate(cycles):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=cycle["code"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        ws.cell(row=r, column=3, value=cycle["nom_complet"]).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()

        for col in [4, 5]:
            c = ws.cell(row=r, column=col, value=0)
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.number_format = '#,##0'

        c_var = ws.cell(row=r, column=6, value="")
        c_var.fill = fill_calculated()
        c_var.border = THIN_BORDER
        c_var.number_format = '#,##0'

        c_pct = ws.cell(row=r, column=7, value="")
        c_pct.fill = fill_calculated()
        c_pct.border = THIN_BORDER
        c_pct.number_format = '0.0%'

        c_concl = ws.cell(row=r, column=8, value="")
        c_concl.fill = fill_input()
        c_concl.border = THIN_BORDER
        c_concl.alignment = align_wrap()

        c_stat = ws.cell(row=r, column=9, value="Non demarre")
        c_stat.fill = fill_input()
        c_stat.border = THIN_BORDER
        c_stat.alignment = align_center()
        dv_statut.add(c_stat)

    return ws


def create_anomalies(wb):
    ws = wb.create_sheet("Anomalies")
    ws.sheet_properties.tabColor = COLORS["rouge"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 8
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 35
    ws.column_dimensions["E"].width = 15
    ws.column_dimensions["F"].width = 15
    ws.column_dimensions["G"].width = 15
    ws.column_dimensions["H"].width = 12
    ws.column_dimensions["I"].width = 12
    ws.column_dimensions["J"].width = 35

    row = 2
    ws.merge_cells("B2:J2")
    cell = ws.cell(row=row, column=2, value="ETAT DES ANOMALIES RELEVEES")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:J3")
    cell = ws.cell(row=row, column=2,
                   value="NEP 450 - Evaluation des anomalies relevees au cours de l'audit")
    cell.font = font_small()
    cell.alignment = align_center()

    row = 5
    write_section_title(ws, row, 2, "RAPPEL DES SEUILS", 5)
    seuil_items = [
        ("Seuil de signification (SS)", "Voir onglet Seuils"),
        ("Seuil de planification (SP)", "Voir onglet Seuils"),
        ("Seuil de remontee", "Voir onglet Seuils"),
    ]
    for i, (label, val) in enumerate(seuil_items):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=4, value=val)
        c.font = Font(name="Calibri", size=10, bold=True, color=COLORS["rouge"])
        c.border = THIN_BORDER

    row = 10
    headers = ["#", "Cycle", "Description de l'anomalie",
               "Impact actif", "Impact passif", "Impact resultat",
               "Corrigee O/N", "Nature", "Observations"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_corrigee = DataValidation(
        type="list",
        formula1='"Oui,Non"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_corrigee)

    dv_nature = DataValidation(
        type="list",
        formula1='"Factuelle,Extrapolee,Jugement"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_nature)

    for i in range(25):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=i + 1).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=2).alignment = align_center()

        for col in range(3, 11):
            c = ws.cell(row=r, column=col, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER

        for col in [5, 6, 7]:
            ws.cell(row=r, column=col).number_format = '#,##0'

        dv_corrigee.add(ws.cell(row=r, column=8))
        dv_nature.add(ws.cell(row=r, column=9))

    total_row = row + 26
    ws.cell(row=total_row, column=2, value="TOTAL").font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
    ws.cell(row=total_row, column=2).border = THIN_BORDER
    for col in [5, 6, 7]:
        c = ws.cell(row=total_row, column=col, value="")
        c.fill = fill_calculated()
        c.border = THIN_BORDER
        c.font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
        c.number_format = '#,##0'

    total_row += 2
    write_section_title(ws, total_row, 2, "EVALUATION GLOBALE DES ANOMALIES", 10)
    eval_fields = [
        "Total des anomalies non corrigees",
        "Comparaison au seuil de signification",
        "Conclusion sur l'impact des anomalies",
        "Lettre d'affirmation couvre les anomalies non corrigees",
    ]
    for i, label in enumerate(eval_fields):
        r = total_row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_subheader()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.merge_cells(start_row=r, start_column=5, end_row=r, end_column=10)
        c = ws.cell(row=r, column=5, value="")
        c.fill = fill_input()
        c.border = THIN_BORDER

    return ws


def create_synthese_generale(wb, profil_code):
    ws = wb.create_sheet("Synthese Generale")
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 35
    ws.column_dimensions["C"].width = 55
    ws.column_dimensions["D"].width = 15

    row = 2
    ws.merge_cells("B2:D2")
    cell = ws.cell(row=row, column=2, value="SYNTHESE GENERALE DU DOSSIER")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    sections = [
        ("IDENTIFICATION", [
            "Entite",
            "Exercice clos le",
            "Associe signataire",
            "Date d'emission du rapport",
        ]),
        ("SEUILS", [
            "Seuil de signification",
            "Seuil de planification",
            "Seuil de remontee",
        ]),
        ("SYNTHESE PAR CYCLE", []),
        ("POINTS CLES DU DOSSIER", [
            "Principales zones de risque",
            "Risques de fraude",
            "Estimations comptables significatives",
            "Evenements posterieurs a la cloture",
            "Continuite d'exploitation",
            "Parties liees",
        ]),
        ("ANOMALIES", [
            "Total des anomalies non corrigees",
            "Impact sur l'opinion",
        ]),
        ("CONTROLE INTERNE", [
            "Points de faiblesse identifies",
            "Points a communiquer a la gouvernance",
        ]),
        ("CONCLUSION", [
            "Opinion proposee",
            "Justification de l'opinion",
            "Paragraphe d'observation",
            "Verification specifique - rapport de gestion",
            "Verification specifique - conventions reglementees",
        ]),
    ]

    current_row = 4
    for section_title, fields in sections:
        write_section_title(ws, current_row, 2, section_title, 4)
        current_row += 1

        if section_title == "SYNTHESE PAR CYCLE":
            cycles = data_loader.get_cycles_for_profil(profil_code)
            for cycle in cycles:
                ws.cell(row=current_row, column=2, value=cycle["nom_complet"]).font = font_normal()
                ws.cell(row=current_row, column=2).border = THIN_BORDER
                c = ws.cell(row=current_row, column=3, value="[Conclusion du cycle]")
                c.fill = fill_input()
                c.border = THIN_BORDER
                c.alignment = align_wrap()
                current_row += 1
        else:
            for field in fields:
                ws.cell(row=current_row, column=2, value=field).font = font_normal()
                ws.cell(row=current_row, column=2).border = THIN_BORDER
                c = ws.cell(row=current_row, column=3, value="")
                c.fill = fill_input()
                c.border = THIN_BORDER
                c.alignment = align_wrap()
                current_row += 1

        current_row += 1

    return ws


def create_points_revue(wb):
    ws = wb.create_sheet("Points Revue")
    ws.sheet_properties.tabColor = COLORS["jaune"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 8
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 40
    ws.column_dimensions["E"].width = 15
    ws.column_dimensions["F"].width = 15
    ws.column_dimensions["G"].width = 40
    ws.column_dimensions["H"].width = 12

    row = 2
    ws.merge_cells("B2:H2")
    cell = ws.cell(row=row, column=2, value="POINTS DE REVUE")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    headers = ["#", "Cycle / Source", "Point identifie",
               "Emetteur", "Destinataire", "Reponse / Action", "Statut"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_statut = DataValidation(
        type="list",
        formula1='"Ouvert,En cours,Resolu,Clos"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_statut)

    dv_dest = DataValidation(
        type="list",
        formula1='"Chef de mission,Manager,Associe"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_dest)

    for i in range(30):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=i + 1).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=2).alignment = align_center()

        for col in range(3, 9):
            c = ws.cell(row=r, column=col, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER
            if col == 4 or col == 7:
                c.alignment = align_wrap()

        dv_dest.add(ws.cell(row=r, column=6))
        dv_statut.add(ws.cell(row=r, column=8))

    return ws


def create_finalisation(wb):
    ws = wb.create_sheet("Finalisation")
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 50
    ws.column_dimensions["C"].width = 12
    ws.column_dimensions["D"].width = 15
    ws.column_dimensions["E"].width = 35

    row = 2
    ws.merge_cells("B2:E2")
    cell = ws.cell(row=row, column=2, value="CHECK-LIST DE FINALISATION")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    headers = ["Point de controle", "Fait O/N", "Date", "Observations"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_fait = DataValidation(
        type="list",
        formula1='"Oui,Non,N/A"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_fait)

    checklist = [
        ("1. PLANIFICATION", None),
        ("Plan de mission etabli et approuve", True),
        ("Seuils determines et documentes", True),
        ("Matrice des risques completee", True),
        ("Equipe briefee", True),
        ("", None),
        ("2. TRAVAUX INTERMEDIAIRES", None),
        ("Controle interne evalue", True),
        ("ITGC evalues", True),
        ("Tests de procedures realises (si applicable)", True),
        ("", None),
        ("3. TRAVAUX FINAUX", None),
        ("Tous les cycles traites", True),
        ("Circularisations envoyees et exploitees", True),
        ("Cut-off ventes et achats realise", True),
        ("Assistance inventaire (si applicable)", True),
        ("Revue analytique de coherence globale", True),
        ("", None),
        ("4. SYNTHESE", None),
        ("Anomalies recensees et evaluees", True),
        ("Synthese par cycle finalisee", True),
        ("Points de revue traites", True),
        ("Evenements posterieurs revus", True),
        ("Continuite d'exploitation evaluee", True),
        ("Lettre d'affirmation obtenue", True),
        ("", None),
        ("5. RAPPORT", None),
        ("Opinion determinee", True),
        ("Rapport redige", True),
        ("Revue manager effectuee", True),
        ("Revue associe effectuee", True),
        ("Rapport signe et emis", True),
        ("", None),
        ("6. ARCHIVAGE", None),
        ("Dossier complet", True),
        ("Documentation suffisante", True),
        ("Dossier cloture dans les 60 jours apres signature rapport", True),
        ("Archivage physique et/ou numerique effectue", True),
    ]

    current_row = row + 1
    for item, is_item in checklist:
        if is_item is None and item:
            write_section_title(ws, current_row, 2, item, 5)
        elif is_item:
            ws.cell(row=current_row, column=2, value=item).font = font_normal()
            ws.cell(row=current_row, column=2).border = THIN_BORDER
            c = ws.cell(row=current_row, column=3, value="Non")
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.alignment = align_center()
            dv_fait.add(c)
            ws.cell(row=current_row, column=4, value="").fill = fill_input()
            ws.cell(row=current_row, column=4).border = THIN_BORDER
            ws.cell(row=current_row, column=5, value="").fill = fill_input()
            ws.cell(row=current_row, column=5).border = THIN_BORDER
        current_row += 1

    return ws
