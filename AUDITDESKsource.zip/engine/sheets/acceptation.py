"""Generate the Acceptation/Maintien and Prise de connaissance sheets."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_acceptation(wb):
    ws = wb.create_sheet("Acceptation")
    ws.sheet_properties.tabColor = COLORS["bleu_moyen"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 45
    ws.column_dimensions["C"].width = 12
    ws.column_dimensions["D"].width = 45

    row = 2
    ws.merge_cells("B2:D2")
    cell = ws.cell(row=row, column=2, value="ACCEPTATION / MAINTIEN DE LA MISSION")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:D3")
    cell = ws.cell(row=row, column=2,
                   value="NEP 210 / NEP 220 - Accord sur les termes de la mission / Controle qualite")
    cell.font = font_small()
    cell.alignment = align_center()

    dv_oui_non = DataValidation(
        type="list",
        formula1='"Oui,Non,N/A"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_oui_non)

    sections = {
        "1. INDEPENDANCE ET DEONTOLOGIE": [
            "Absence de liens financiers avec l'entite",
            "Absence de liens personnels avec les dirigeants",
            "Absence de prestations incompatibles",
            "Respect du delai de vidurite (si applicable)",
            "Rotation de l'associe respectee (si EIP)",
            "Declaration d'independance signee par l'equipe",
        ],
        "2. COMPETENCE ET MOYENS": [
            "Competences necessaires disponibles au cabinet",
            "Budget d'heures suffisant",
            "Pas de conflit de calendrier majeur",
            "Expert necessaire (evaluation, fiscal, SI)",
        ],
        "3. RISQUES LIES A LA MISSION": [
            "Risques identifies liees a l'entite ou son secteur",
            "Risque de blanchiment identifie (LCB-FT)",
            "Obligation de declaration Canta verifiee",
            "Continuite d'exploitation de l'entite non compromise",
            "Contentieux en cours impliquant l'entite",
            "Changement de direction recent",
        ],
        "4. LETTRE DE MISSION": [
            "Lettre de mission signee",
            "Conditions financieres definies",
            "Perimetre de la mission defini",
            "Obligations reciproques precises",
        ],
        "5. MAINTIEN (si renouvellement)": [
            "Evenements remettant en cause le maintien",
            "Qualite de la relation avec la direction",
            "Honoraires adequats",
            "Points significatifs de l'exercice precedent traites",
        ],
    }

    current_row = 5
    for section_title, questions in sections.items():
        write_section_title(ws, current_row, 2, section_title, 4)
        current_row += 1

        for question in questions:
            ws.cell(row=current_row, column=2, value=question).font = font_normal()
            ws.cell(row=current_row, column=2).border = THIN_BORDER

            c = ws.cell(row=current_row, column=3, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.alignment = align_center()
            dv_oui_non.add(c)

            c_obs = ws.cell(row=current_row, column=4, value="")
            c_obs.fill = fill_input()
            c_obs.border = THIN_BORDER
            c_obs.alignment = align_wrap()

            current_row += 1

        current_row += 1

    write_section_title(ws, current_row, 2, "CONCLUSION", 4)
    current_row += 1

    ws.cell(row=current_row, column=2, value="Decision").font = font_subheader()
    ws.cell(row=current_row, column=2).border = THIN_BORDER

    dv_decision = DataValidation(
        type="list",
        formula1='"Acceptation,Maintien,Refus,Demission"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_decision)
    c = ws.cell(row=current_row, column=3, value="")
    c.fill = fill_input()
    c.border = THIN_BORDER
    dv_decision.add(c)

    current_row += 1
    ws.cell(row=current_row, column=2, value="Justification").font = font_normal()
    ws.cell(row=current_row, column=2).border = THIN_BORDER
    ws.merge_cells(start_row=current_row, start_column=3, end_row=current_row + 2, end_column=4)
    c = ws.cell(row=current_row, column=3, value="")
    c.fill = fill_input()
    c.border = THIN_BORDER
    c.alignment = align_wrap()

    return ws


def create_prise_connaissance(wb, profil_code):
    ws = wb.create_sheet("Prise Connaissance")
    ws.sheet_properties.tabColor = COLORS["bleu_moyen"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 45
    ws.column_dimensions["C"].width = 55

    row = 2
    ws.merge_cells("B2:C2")
    cell = ws.cell(row=row, column=2, value="PRISE DE CONNAISSANCE DE L'ENTITE")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:C3")
    cell = ws.cell(row=row, column=2,
                   value="NEP 315 - Connaissance de l'entite et de son environnement")
    cell.font = font_small()
    cell.alignment = align_center()

    sections = {
        "1. ENVIRONNEMENT GENERAL": [
            "Secteur d'activite et environnement economique",
            "Cadre reglementaire applicable",
            "Marche et concurrence",
            "Saisonnalite de l'activite",
            "Facteurs externes significatifs",
        ],
        "2. GOUVERNANCE ET ORGANISATION": [
            "Structure juridique et organigramme",
            "Composition de la direction",
            "Organe de surveillance (CA, CS, etc.)",
            "Politique de delegation",
            "Processus de decision",
        ],
        "3. ACTIVITE ET MODELE ECONOMIQUE": [
            "Description de l'activite principale",
            "Principales sources de revenus",
            "Principaux clients et fournisseurs",
            "Concentration du CA",
            "Politique de prix",
        ],
        "4. OBJECTIFS ET STRATEGIES": [
            "Objectifs declares par la direction",
            "Strategie de developpement",
            "Investissements prevus",
            "Risques strategiques identifies par la direction",
        ],
        "5. PERFORMANCE FINANCIERE": [
            "Indicateurs de performance suivis par la direction",
            "Evolution du CA sur 3 ans",
            "Evolution du resultat sur 3 ans",
            "Structure financiere",
            "Politique de distribution",
        ],
        "6. REFERENTIEL COMPTABLE": [
            "Referentiel comptable applique",
            "Methodes comptables significatives",
            "Changements de methodes sur l'exercice",
            "Estimations comptables significatives",
        ],
    }

    current_row = 5
    for section_title, items in sections.items():
        write_section_title(ws, current_row, 2, section_title, 3)
        current_row += 1

        for item in items:
            ws.cell(row=current_row, column=2, value=item).font = font_normal()
            ws.cell(row=current_row, column=2).border = THIN_BORDER
            c = ws.cell(row=current_row, column=3, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER
            c.alignment = align_wrap()
            current_row += 1

        current_row += 1

    return ws
