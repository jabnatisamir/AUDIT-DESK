"""Generate the Matrice des Risques sheet."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    fill_risk, font_risk,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from engine import data_loader
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_matrice_risques(wb, mission_data, profil_code):
    ws = wb.create_sheet("Matrice Risques")
    ws.sheet_properties.tabColor = COLORS["rouge"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 8
    ws.column_dimensions["C"].width = 15
    ws.column_dimensions["D"].width = 8
    ws.column_dimensions["E"].width = 35
    ws.column_dimensions["F"].width = 30
    ws.column_dimensions["G"].width = 14
    ws.column_dimensions["H"].width = 14
    ws.column_dimensions["I"].width = 14
    ws.column_dimensions["J"].width = 35
    ws.column_dimensions["K"].width = 14
    ws.column_dimensions["L"].width = 35

    row = 2
    ws.merge_cells("B2:L2")
    cell = ws.cell(row=row, column=2, value="MATRICE DES RISQUES D'ANOMALIES SIGNIFICATIVES")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:L3")
    cell = ws.cell(row=row, column=2,
                   value="NEP 315 / NEP 330 - Identification, evaluation des risques et reponses d'audit")
    cell.font = font_small()
    cell.alignment = align_center()

    row = 5
    ws.merge_cells("B5:D5")
    ws.cell(row=row, column=2, value="Rappel des seuils :").font = font_subheader()
    seuil_labels = [
        ("Seuil de signification (SS)", "E5"),
        ("Seuil de planification (SP)", "G5"),
        ("Seuil de remontee", "I5"),
    ]
    for label, cell_ref in seuil_labels:
        ws.cell(row=5, column=_col(cell_ref), value=label).font = font_small()
        c = ws.cell(row=5, column=_col(cell_ref) + 1, value="Voir onglet Seuils")
        c.font = Font(name="Calibri", size=10, bold=True, color=COLORS["rouge"])

    row = 7
    headers = [
        "Code", "Cycle", "Assert.", "Risque identifie",
        "Facteurs de risque", "R. Inherent", "R. Controle",
        "R. Combine", "Reponse d'audit prevue",
        "Approche", "Observations"
    ]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_risk = DataValidation(
        type="list",
        formula1='"Faible,Modere,Eleve,Significatif"',
        allow_blank=True,
    )
    dv_risk.error = "Choisir un niveau de risque"
    dv_risk.errorTitle = "Niveau invalide"
    ws.add_data_validation(dv_risk)

    dv_approche = DataValidation(
        type="list",
        formula1='"Substantif,Mixte,Tests de controle,Analytique"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_approche)

    cycles = data_loader.get_cycles_for_profil(profil_code)
    current_row = row + 1

    for cycle in cycles:
        risques = data_loader.get_risques_for_cycle(cycle["code"])
        profil = data_loader.get_profil(profil_code)
        risques_sectoriels = [r for r in profil.get("risques_specifiques", []) if r["cycle"] == cycle["code"]]

        if not risques and not risques_sectoriels:
            r = current_row
            ws.cell(row=r, column=2, value="").border = THIN_BORDER
            ws.cell(row=r, column=3, value=cycle["nom"]).font = font_normal()
            ws.cell(row=r, column=3).border = THIN_BORDER
            ws.cell(row=r, column=4, value="").border = THIN_BORDER
            ws.cell(row=r, column=5, value="Aucun risque specifique identifie").font = font_small()
            ws.cell(row=r, column=5).border = THIN_BORDER
            for col in range(6, 13):
                ws.cell(row=r, column=col).border = THIN_BORDER
            current_row += 1
            continue

        for risque in risques:
            r = current_row
            code = risque.get("code", "")
            ws.cell(row=r, column=2, value=code).font = font_normal()
            ws.cell(row=r, column=2).border = THIN_BORDER

            ws.cell(row=r, column=3, value=cycle["nom"]).font = font_normal()
            ws.cell(row=r, column=3).border = THIN_BORDER

            assertions = risque.get("assertion", risque.get("assertions", [""])  )
            if isinstance(assertions, list):
                assertions = ", ".join(assertions)
            ws.cell(row=r, column=4, value=assertions).font = font_normal()
            ws.cell(row=r, column=4).border = THIN_BORDER
            ws.cell(row=r, column=4).alignment = align_center()

            ws.cell(row=r, column=5, value=risque.get("intitule", "")).font = font_normal()
            ws.cell(row=r, column=5).border = THIN_BORDER
            ws.cell(row=r, column=5).alignment = align_wrap()

            facteurs = risque.get("facteurs", [])
            if isinstance(facteurs, list):
                facteurs = "\n".join(f"- {f}" for f in facteurs)
            ws.cell(row=r, column=6, value=facteurs).font = font_small()
            ws.cell(row=r, column=6).border = THIN_BORDER
            ws.cell(row=r, column=6).alignment = align_wrap()

            niveau = risque.get("niveau_inherent_defaut", risque.get("niveau_defaut", "Modere"))
            c_ri = ws.cell(row=r, column=7, value=niveau)
            c_ri.font = font_risk(niveau)
            c_ri.fill = fill_risk(niveau)
            c_ri.border = THIN_BORDER
            c_ri.alignment = align_center()
            dv_risk.add(c_ri)

            c_rc = ws.cell(row=r, column=8, value="Modere")
            c_rc.fill = fill_input()
            c_rc.border = THIN_BORDER
            c_rc.alignment = align_center()
            dv_risk.add(c_rc)

            c_rcomb = ws.cell(row=r, column=9, value=niveau)
            c_rcomb.font = font_risk(niveau)
            c_rcomb.fill = fill_risk(niveau)
            c_rcomb.border = THIN_BORDER
            c_rcomb.alignment = align_center()
            dv_risk.add(c_rcomb)

            ws.cell(row=r, column=10, value=risque.get("reponse_audit_type", "")).font = font_normal()
            ws.cell(row=r, column=10).border = THIN_BORDER
            ws.cell(row=r, column=10).alignment = align_wrap()

            c_app = ws.cell(row=r, column=11, value="Substantif")
            c_app.fill = fill_input()
            c_app.border = THIN_BORDER
            c_app.alignment = align_center()
            dv_approche.add(c_app)

            ws.cell(row=r, column=12, value="").font = font_normal()
            ws.cell(row=r, column=12).fill = fill_input()
            ws.cell(row=r, column=12).border = THIN_BORDER

            current_row += 1

        for rs in risques_sectoriels:
            r = current_row
            ws.cell(row=r, column=2, value=rs.get("code", "")).font = font_normal()
            ws.cell(row=r, column=2).border = THIN_BORDER
            ws.cell(row=r, column=3, value=cycle["nom"]).font = font_normal()
            ws.cell(row=r, column=3).border = THIN_BORDER
            ws.cell(row=r, column=4, value="").border = THIN_BORDER
            ws.cell(row=r, column=5, value=rs.get("intitule", "")).font = font_normal()
            ws.cell(row=r, column=5).border = THIN_BORDER
            ws.cell(row=r, column=5).alignment = align_wrap()
            ws.cell(row=r, column=6, value="[Risque sectoriel]").font = font_small()
            ws.cell(row=r, column=6).border = THIN_BORDER

            niveau = rs.get("niveau_defaut", "Modere")
            c_ri = ws.cell(row=r, column=7, value=niveau)
            c_ri.font = font_risk(niveau)
            c_ri.fill = fill_risk(niveau)
            c_ri.border = THIN_BORDER
            c_ri.alignment = align_center()
            dv_risk.add(c_ri)

            for col in [8, 9]:
                c = ws.cell(row=r, column=col, value="Modere")
                c.fill = fill_input()
                c.border = THIN_BORDER
                c.alignment = align_center()
                dv_risk.add(c)

            ws.cell(row=r, column=10, value="").fill = fill_input()
            ws.cell(row=r, column=10).border = THIN_BORDER
            ws.cell(row=r, column=11, value="Substantif").fill = fill_input()
            ws.cell(row=r, column=11).border = THIN_BORDER
            ws.cell(row=r, column=11).alignment = align_center()
            dv_approche.add(ws.cell(row=r, column=11))
            ws.cell(row=r, column=12, value="").fill = fill_input()
            ws.cell(row=r, column=12).border = THIN_BORDER

            current_row += 1

    return ws


def _col(cell_ref):
    """Extract column number from a cell reference like 'E5'."""
    from openpyxl.utils import column_index_from_string
    col_letter = "".join(c for c in cell_ref if c.isalpha())
    return column_index_from_string(col_letter)
