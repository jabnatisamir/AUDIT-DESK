"""Generate the Seuils (materiality thresholds) sheet."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from openpyxl.styles import Font, PatternFill, numbers


def create_seuils(wb, mission_data, seuils_ref):
    ws = wb.create_sheet("Seuils")
    ws.sheet_properties.tabColor = COLORS["bleu_moyen"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 40
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 20
    ws.column_dimensions["E"].width = 20
    ws.column_dimensions["F"].width = 40

    row = 2
    ws.merge_cells("B2:F2")
    cell = ws.cell(row=row, column=2, value="DETERMINATION DES SEUILS DE SIGNIFICATION")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 4
    ws.merge_cells("B4:F4")
    cell = ws.cell(row=row, column=2,
                   value="NEP 320 - Le seuil de signification est le montant au-dela duquel les decisions economiques "
                         "ou le jugement fonde sur les comptes sont susceptibles d'etre influences.")
    cell.font = font_small()
    cell.alignment = align_wrap()

    row = 6
    write_section_title(ws, row, 2, "1. CHOIX DE L'AGREGAT DE REFERENCE", 6)

    row = 7
    headers = ["Agregat", "Montant", "Taux bas", "Taux haut", "Commentaire"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    profil = mission_data.get("mission", {}).get("entite", {}).get("profil_entite", "societe_commerciale")
    methode_key = "societe_commerciale"
    if "asso" in profil.lower() or "ess" in profil.lower() or "spectacle" in profil.lower():
        methode_key = "association"
    elif "coop" in profil.lower():
        methode_key = "cooperative"

    methodes = seuils_ref.get("methodes_calcul", {}).get(methode_key, [])

    for i, m in enumerate(methodes):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=m["agregat"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        c = ws.cell(row=r, column=3, value=0)
        c.font = font_normal()
        c.fill = fill_input()
        c.border = THIN_BORDER
        c.number_format = '#,##0'

        ws.cell(row=r, column=4, value=f"{m['fourchette_basse_pct']}%").font = font_normal()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=4).alignment = align_center()

        ws.cell(row=r, column=5, value=f"{m['fourchette_haute_pct']}%").font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=5).alignment = align_center()

        ws.cell(row=r, column=6, value=m["commentaire"]).font = font_small()
        ws.cell(row=r, column=6).border = THIN_BORDER

    row = row + len(methodes) + 2
    write_section_title(ws, row, 2, "2. CALCUL DES SEUILS", 6)

    seuil_fields = [
        ("Agregat retenu", "[A completer]", True, ""),
        ("Montant de l'agregat", 0, True, '#,##0'),
        ("Taux retenu pour le seuil de signification", "", True, "0.00%"),
        ("SEUIL DE SIGNIFICATION (SS)", "", False, '#,##0'),
        ("", "", False, ""),
        ("Ratio seuil de planification / SS", "75%", True, ""),
        ("SEUIL DE PLANIFICATION (SP)", "", False, '#,##0'),
        ("", "", False, ""),
        ("Ratio seuil de remontee / SS", "5%", True, ""),
        ("SEUIL DE REMONTEE DES ANOMALIES", "", False, '#,##0'),
    ]

    for i, (label, default, is_input, fmt) in enumerate(seuil_fields):
        r = row + 1 + i
        cell_label = ws.cell(row=r, column=2, value=label)
        cell_label.border = THIN_BORDER
        if "SEUIL" in label:
            cell_label.font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
        else:
            cell_label.font = font_normal()

        c = ws.cell(row=r, column=3, value=default)
        c.border = THIN_BORDER
        if is_input:
            c.fill = fill_input()
            c.font = font_normal()
        else:
            c.fill = fill_calculated()
            c.font = Font(name="Calibri", size=11, bold=True, color=COLORS["bleu_fonce"])
        if fmt:
            c.number_format = fmt

    row = row + len(seuil_fields) + 2
    write_section_title(ws, row, 2, "3. SEUILS SPECIFIQUES PAR CYCLE", 6)

    row += 1
    spec_headers = ["Cycle / Information", "Seuil specifique", "Justification"]
    for i, h in enumerate(spec_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    specifiques = [
        "Parties liees",
        "Remuneration des dirigeants",
        "Provisions pour risques",
        "Engagements hors bilan",
        "Informations sensibles annexe",
    ]

    for i, s in enumerate(specifiques):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=s).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=3, value="")
        c.fill = fill_input()
        c.border = THIN_BORDER
        c.number_format = '#,##0'
        c2 = ws.cell(row=r, column=4, value="")
        c2.fill = fill_input()
        c2.border = THIN_BORDER

    row = row + len(specifiques) + 2
    write_section_title(ws, row, 2, "4. JUSTIFICATION DU JUGEMENT PROFESSIONNEL", 6)

    row += 1
    ws.merge_cells(start_row=row, start_column=2, end_row=row + 4, end_column=6)
    c = ws.cell(row=row, column=2, value="[Documenter ici la justification du choix de l'agregat, "
                "du taux retenu, et des eventuels seuils specifiques.]")
    c.font = font_normal()
    c.fill = fill_input()
    c.alignment = align_wrap()
    c.border = THIN_BORDER

    return ws
