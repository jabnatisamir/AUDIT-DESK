"""Generate a cycle work sheet (feuille de travail par cycle)."""

from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    fill_risk, font_risk,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)
from engine import data_loader
from openpyxl.styles import Font
from openpyxl.worksheet.datavalidation import DataValidation


def create_cycle_sheet(wb, cycle, profil_code):
    sheet_name = f"CY-{cycle['nom']}"
    if len(sheet_name) > 31:
        sheet_name = sheet_name[:31]

    ws = wb.create_sheet(sheet_name)
    ws.sheet_properties.tabColor = COLORS["vert"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 35
    ws.column_dimensions["D"].width = 10
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 35
    ws.column_dimensions["G"].width = 12
    ws.column_dimensions["H"].width = 35
    ws.column_dimensions["I"].width = 15
    ws.column_dimensions["J"].width = 12
    ws.column_dimensions["K"].width = 12
    ws.column_dimensions["L"].width = 12

    row = 2
    ws.merge_cells(f"B2:L2")
    cell = ws.cell(row=row, column=2, value=f"FEUILLE DE TRAVAIL - {cycle['nom_complet'].upper()}")
    cell.font = Font(name="Calibri", size=14, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells(f"B3:L3")
    cell = ws.cell(row=row, column=2, value=f"Cycle {cycle['code']} - Comptes principaux : {', '.join(cycle['comptes_principaux'][:8])}...")
    cell.font = font_small()
    cell.alignment = align_center()

    # --- Section: Seuils rappel ---
    row = 5
    write_section_title(ws, row, 2, "RAPPEL DES SEUILS", 6)
    seuil_items = [
        ("Seuil de signification (SS)", "Voir onglet Seuils"),
        ("Seuil de planification (SP)", "Voir onglet Seuils"),
        ("Seuil de remontee", "Voir onglet Seuils"),
    ]
    for i, (label, val) in enumerate(seuil_items):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        c = ws.cell(row=r, column=4, value=val)
        c.font = Font(name="Calibri", size=10, bold=True, color=COLORS["rouge"])
        c.border = THIN_BORDER

    # --- Section: Risques identifies ---
    row = 10
    write_section_title(ws, row, 2, "RISQUES IDENTIFIES SUR LE CYCLE", 12)

    row += 1
    risk_headers = ["Code", "Intitule du risque", "Assert.", "Niveau", "Reponse prevue"]
    for i, h in enumerate(risk_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    risques = data_loader.get_risques_for_cycle(cycle["code"])
    profil = data_loader.get_profil(profil_code)
    risques_sect = [r for r in profil.get("risques_specifiques", []) if r["cycle"] == cycle["code"]]

    all_risques = risques + risques_sect
    for i, risque in enumerate(all_risques):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=risque.get("code", "")).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        ws.cell(row=r, column=3, value=risque.get("intitule", "")).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()

        assertions = risque.get("assertion", risque.get("assertions", [""]))
        if isinstance(assertions, list):
            assertions = ", ".join(assertions)
        ws.cell(row=r, column=4, value=assertions).font = font_normal()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=4).alignment = align_center()

        niveau = risque.get("niveau_inherent_defaut", risque.get("niveau_defaut", "Modere"))
        c = ws.cell(row=r, column=5, value=niveau)
        c.font = font_risk(niveau)
        c.fill = fill_risk(niveau)
        c.border = THIN_BORDER
        c.alignment = align_center()

        reponse = risque.get("reponse_audit_type", "")
        ws.cell(row=r, column=6, value=reponse).font = font_small()
        ws.cell(row=r, column=6).border = THIN_BORDER
        ws.cell(row=r, column=6).alignment = align_wrap()

    # --- Section: Programme de travail ---
    row = row + len(all_risques) + 3
    write_section_title(ws, row, 2, "PROGRAMME DE TRAVAIL", 12)

    row += 1
    pt_headers = ["Code", "Procedure d'audit", "Nature", "Assert.",
                   "Travaux realises", "Ref. FT", "Conclusion", "Statut"]
    for i, h in enumerate(pt_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    procedures = data_loader.get_programmes_for_cycle(cycle["code"])

    dv_statut = DataValidation(
        type="list",
        formula1='"Non demarre,En cours,Termine,N/A"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_statut)

    for i, proc in enumerate(procedures):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=proc["code"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER

        ws.cell(row=r, column=3, value=proc["intitule"]).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()

        ws.cell(row=r, column=4, value=proc["nature"]).font = font_normal()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=4).alignment = align_center()

        assertions = ", ".join(proc.get("assertions", []))
        ws.cell(row=r, column=5, value=assertions).font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=5).alignment = align_center()

        c_travaux = ws.cell(row=r, column=6, value="")
        c_travaux.fill = fill_input()
        c_travaux.border = THIN_BORDER
        c_travaux.alignment = align_wrap()

        c_ref = ws.cell(row=r, column=7, value="")
        c_ref.fill = fill_input()
        c_ref.border = THIN_BORDER

        c_concl = ws.cell(row=r, column=8, value="")
        c_concl.fill = fill_input()
        c_concl.border = THIN_BORDER
        c_concl.alignment = align_wrap()

        c_statut = ws.cell(row=r, column=9, value="Non demarre")
        c_statut.fill = fill_input()
        c_statut.border = THIN_BORDER
        c_statut.alignment = align_center()
        dv_statut.add(c_statut)

    # --- Section: Zone de tests ---
    row = row + len(procedures) + 3
    write_section_title(ws, row, 2, "ZONE DE TESTS ET TRAVAUX DETAILLES", 12)

    row += 1
    test_headers = ["Ref.", "Description du test", "Critere selection",
                    "Echantillon", "Resultat", "Anomalie O/N",
                    "Montant impact", "Commentaire"]
    for i, h in enumerate(test_headers):
        c = ws.cell(row=row, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    dv_anomalie = DataValidation(
        type="list",
        formula1='"Oui,Non"',
        allow_blank=True,
    )
    ws.add_data_validation(dv_anomalie)

    for i in range(15):
        r = row + 1 + i
        for col in range(2, 10):
            c = ws.cell(row=r, column=col, value="")
            c.fill = fill_input()
            c.border = THIN_BORDER
        dv_anomalie.add(ws.cell(row=r, column=7))
        ws.cell(row=r, column=8).number_format = '#,##0'

    # --- Section: Synthese du cycle ---
    row = row + 17
    write_section_title(ws, row, 2, "SYNTHESE DU CYCLE", 12)

    synth_fields = [
        ("Conclusion sur le cycle", ""),
        ("Anomalies identifiees", ""),
        ("Faiblesses de controle interne", ""),
        ("Points de jugement", ""),
        ("Points a remonter en synthese generale", "Oui / Non"),
        ("Points a communiquer a la gouvernance", "Oui / Non"),
    ]

    for i, (label, default) in enumerate(synth_fields):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_subheader()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.merge_cells(start_row=r, start_column=4, end_row=r, end_column=12)
        c = ws.cell(row=r, column=4, value=default)
        c.fill = fill_input()
        c.border = THIN_BORDER
        c.alignment = align_wrap()

    return ws
