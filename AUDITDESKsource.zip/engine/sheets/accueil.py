"""Generate the Accueil (home) sheet."""

from openpyxl.utils import get_column_letter
from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title, apply_header_row,
)
from openpyxl.styles import Font, PatternFill, Alignment


def create_accueil(wb, mission_data):
    ws = wb.active
    ws.title = "ACCUEIL"
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 20
    ws.column_dimensions["E"].width = 20
    ws.column_dimensions["F"].width = 20

    row = 2
    ws.merge_cells("B2:F2")
    cell = ws.cell(row=row, column=2, value="AUDIT-DESK - DOSSIER DE TRAVAIL")
    cell.font = Font(name="Calibri", size=18, bold=True, color=COLORS["bleu_fonce"])
    cell.alignment = align_center()

    row = 3
    ws.merge_cells("B3:F3")
    cell = ws.cell(row=row, column=2, value="Outil de gestion et de formalisation de la mission CAC")
    cell.font = Font(name="Calibri", size=12, color=COLORS["bleu_moyen"])
    cell.alignment = align_center()

    row = 5
    write_section_title(ws, row, 2, "IDENTIFICATION DE LA MISSION", 6)

    fields = [
        ("Entite", "entite", "raison_sociale"),
        ("Forme juridique", "entite", "forme_juridique"),
        ("SIREN", "entite", "siren"),
        ("Activite", "entite", "activite"),
        ("Profil d'entite", "entite", "profil_entite"),
        ("Exercice clos le", "entite", "exercice_clos_le"),
    ]

    for i, (label, section, key) in enumerate(fields):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        val = mission_data.get("mission", {}).get(section, {}).get(key, "")
        c = ws.cell(row=r, column=3, value=val if val else "[A completer]")
        c.font = font_normal()
        c.fill = fill_input()
        c.border = THIN_BORDER

    row = row + len(fields) + 2
    write_section_title(ws, row, 2, "EQUIPE MISSION", 6)

    team_fields = [
        ("Associe signataire", "associe_signataire"),
        ("Manager", "manager"),
        ("Chef de mission", "chef_de_mission"),
    ]

    for i, (label, key) in enumerate(team_fields):
        r = row + 1 + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        val = mission_data.get("mission", {}).get("equipe", {}).get(key, "")
        c = ws.cell(row=r, column=3, value=val if val else "[A completer]")
        c.font = font_normal()
        c.fill = fill_input()
        c.border = THIN_BORDER

    row = row + len(team_fields) + 2
    write_section_title(ws, row, 2, "JALONS CLES", 6)

    headers = ["Jalon", "Date prevue", "Date realisee", "Statut"]
    for i, h in enumerate(headers):
        c = ws.cell(row=row + 1, column=2 + i, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    jalons_list = [
        ("Acceptation / maintien", "date_acceptation"),
        ("Planification", "date_planification"),
        ("Interim", "date_interim"),
        ("Inventaire", "date_inventaire"),
        ("Final", "date_final"),
        ("Synthese / revue", "date_synthese"),
        ("Revue manager", "date_revue_manager"),
        ("Revue associe", "date_revue_associe"),
        ("Emission du rapport", "date_emission_rapport"),
        ("AG d'approbation", "date_ag_approbation"),
        ("Archivage (limite 60j)", "date_archivage_limite"),
    ]

    for i, (label, key) in enumerate(jalons_list):
        r = row + 2 + i
        ws.cell(row=r, column=2, value=label).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        val = mission_data.get("mission", {}).get("jalons", {}).get(key, "")
        c = ws.cell(row=r, column=3, value=val if val else "")
        c.font = font_normal()
        c.fill = fill_input()
        c.border = THIN_BORDER
        c2 = ws.cell(row=r, column=4, value="")
        c2.fill = fill_input()
        c2.border = THIN_BORDER
        c3 = ws.cell(row=r, column=5, value="Non demarre")
        c3.fill = fill_input()
        c3.border = THIN_BORDER

    row = row + len(jalons_list) + 3
    write_section_title(ws, row, 2, "SOMMAIRE DU DOSSIER", 6)

    sections = [
        ("A", "PILOTAGE", ["ACCUEIL", "Parametres", "Planning", "Dashboard", "Rentabilite"]),
        ("B", "APPROCHE", ["Acceptation", "Prise connaissance", "Seuils", "Planification", "Matrice risques"]),
        ("C", "CONTROLE INTERNE / SI", ["Cartographie SI", "ITGC", "ITAC", "Synthese CI"]),
        ("D", "CYCLES", []),
        ("E", "FINALISATION", ["Feuilles maitresses", "Anomalies", "Synthese generale", "Points revue", "Finalisation", "Rapport"]),
        ("F", "GESTION CABINET", ["Temps", "Budget", "Facturation", "Boni-Mali"]),
    ]

    for section_letter, section_name, sheets in sections:
        row += 1
        ws.cell(row=row, column=2, value=f"{section_letter}. {section_name}").font = font_subheader()
        ws.cell(row=row, column=2).border = THIN_BORDER
        for sheet_name in sheets:
            row += 1
            ws.cell(row=row, column=3, value=sheet_name).font = font_small()
            ws.cell(row=row, column=3).border = THIN_BORDER

    return ws
