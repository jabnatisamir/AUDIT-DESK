"""Load reference data from JSON files."""

import json
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REF_DIR = os.path.join(BASE_DIR, "referentiel")
CONFIG_DIR = os.path.join(BASE_DIR, "config")


def load_json(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)


def load_cycles():
    return load_json(os.path.join(REF_DIR, "cycles.json"))["cycles"]


def load_assertions():
    return load_json(os.path.join(REF_DIR, "assertions.json"))["assertions"]


def load_risques():
    return load_json(os.path.join(REF_DIR, "risques.json"))


def load_profils():
    return load_json(os.path.join(REF_DIR, "profils_entites.json"))["profils"]


def load_controles():
    return load_json(os.path.join(REF_DIR, "controles.json"))


def load_programmes():
    return load_json(os.path.join(REF_DIR, "programmes_travail.json"))


def load_seuils():
    return load_json(os.path.join(REF_DIR, "seuils.json"))


def load_mission_template():
    return load_json(os.path.join(CONFIG_DIR, "mission_template.json"))


def get_profil(code):
    profils = load_profils()
    for p in profils:
        if p["code"] == code:
            return p
    return profils[0]


def get_cycles_for_profil(profil_code):
    profil = get_profil(profil_code)
    all_cycles = load_cycles()
    active_codes = profil["cycles_actifs"]
    return [c for c in all_cycles if c["code"] in active_codes]


def get_risques_for_cycle(cycle_code):
    data = load_risques()
    result = [r for r in data["risques_generaux"] if r["cycle"] == cycle_code]
    for rf in data["risques_fraude"]:
        if cycle_code in rf["cycles_concernes"]:
            result.append(rf)
    return result


def get_programmes_for_cycle(cycle_code):
    data = load_programmes()
    for p in data["programmes"]:
        if p["cycle"] == cycle_code:
            return p["procedures"]
    return []


def get_controles_for_cycle(cycle_code):
    data = load_controles()
    return [c for c in data["controles_cles"] if c["cycle"] == cycle_code]
