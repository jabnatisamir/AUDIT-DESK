"""Generate the Parametres Cabinet workbook — the reference data master."""

import os
from openpyxl import Workbook
from openpyxl.styles import Font

from engine import data_loader
from engine.styles import (
    font_header, font_subheader, font_normal, font_small,
    fill_header, fill_subheader, fill_input, fill_calculated,
    fill_risk, font_risk,
    align_center, align_left, align_wrap,
    THIN_BORDER, COLORS, write_section_title,
)


def generate_parametres_cabinet(output_path=None):
    if output_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(base_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "Parametres_Cabinet.xlsx")

    wb = Workbook()

    _create_ref_cycles(wb)
    _create_ref_assertions(wb)
    _create_ref_risques(wb)
    _create_ref_controles(wb)
    _create_ref_profils(wb)
    _create_ref_programmes(wb)
    _create_ref_seuils(wb)

    wb.remove(wb["Sheet"])
    wb.save(output_path)
    print(f"Parametres cabinet genere: {output_path} ({len(wb.sheetnames)} onglets)")
    return output_path


def _create_ref_cycles(wb):
    ws = wb.create_sheet("Ref_Cycles")
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    headers = ["Code", "Nom", "Nom complet", "Comptes principaux", "Assertions cles", "Ordre"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    for j, cycle in enumerate(data_loader.load_cycles()):
        r = j + 2
        ws.cell(row=r, column=1, value=cycle["code"]).font = font_normal()
        ws.cell(row=r, column=1).border = THIN_BORDER
        ws.cell(row=r, column=2, value=cycle["nom"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=3, value=cycle["nom_complet"]).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=4, value=", ".join(cycle["comptes_principaux"])).font = font_small()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=5, value=", ".join(cycle["assertions_cles"])).font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=6, value=cycle["ordre"]).font = font_normal()
        ws.cell(row=r, column=6).border = THIN_BORDER

    for col_letter, width in [("A", 8), ("B", 25), ("C", 45), ("D", 50), ("E", 20), ("F", 8)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_assertions(wb):
    ws = wb.create_sheet("Ref_Assertions")
    ws.sheet_properties.tabColor = COLORS["bleu_fonce"]

    headers = ["Categorie", "Code", "Nom", "Description"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    assertions = data_loader.load_assertions()
    row = 2
    for cat_key, cat_name in [
        ("flux_operations", "Flux d'operations"),
        ("soldes_comptes", "Soldes de comptes"),
        ("presentation_informations", "Presentation et informations"),
    ]:
        for a in assertions[cat_key]:
            ws.cell(row=row, column=1, value=cat_name).font = font_normal()
            ws.cell(row=row, column=1).border = THIN_BORDER
            ws.cell(row=row, column=2, value=a["code"]).font = font_normal()
            ws.cell(row=row, column=2).border = THIN_BORDER
            ws.cell(row=row, column=3, value=a["nom"]).font = font_normal()
            ws.cell(row=row, column=3).border = THIN_BORDER
            ws.cell(row=row, column=4, value=a["description"]).font = font_small()
            ws.cell(row=row, column=4).border = THIN_BORDER
            ws.cell(row=row, column=4).alignment = align_wrap()
            row += 1

    for col_letter, width in [("A", 30), ("B", 8), ("C", 25), ("D", 70)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_risques(wb):
    ws = wb.create_sheet("Ref_Risques")
    ws.sheet_properties.tabColor = COLORS["rouge"]

    headers = ["Code", "Cycle", "Assertion", "Intitule", "Facteurs", "Niveau defaut", "Reponse type"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    risques_data = data_loader.load_risques()

    row = 2
    for r_data in risques_data["risques_generaux"]:
        ws.cell(row=row, column=1, value=r_data["code"]).font = font_normal()
        ws.cell(row=row, column=1).border = THIN_BORDER
        ws.cell(row=row, column=2, value=r_data["cycle"]).font = font_normal()
        ws.cell(row=row, column=2).border = THIN_BORDER
        ws.cell(row=row, column=3, value=r_data["assertion"]).font = font_normal()
        ws.cell(row=row, column=3).border = THIN_BORDER
        ws.cell(row=row, column=4, value=r_data["intitule"]).font = font_normal()
        ws.cell(row=row, column=4).border = THIN_BORDER
        ws.cell(row=row, column=4).alignment = align_wrap()
        facteurs = ", ".join(r_data.get("facteurs", []))
        ws.cell(row=row, column=5, value=facteurs).font = font_small()
        ws.cell(row=row, column=5).border = THIN_BORDER
        ws.cell(row=row, column=5).alignment = align_wrap()

        niveau = r_data["niveau_inherent_defaut"]
        c_niv = ws.cell(row=row, column=6, value=niveau)
        c_niv.font = font_risk(niveau)
        c_niv.fill = fill_risk(niveau)
        c_niv.border = THIN_BORDER
        c_niv.alignment = align_center()

        ws.cell(row=row, column=7, value=r_data["reponse_audit_type"]).font = font_small()
        ws.cell(row=row, column=7).border = THIN_BORDER
        ws.cell(row=row, column=7).alignment = align_wrap()
        row += 1

    row += 1
    write_section_title(ws, row, 1, "RISQUES DE FRAUDE (NEP 240)", 7)
    row += 1
    for rf in risques_data["risques_fraude"]:
        ws.cell(row=row, column=1, value=rf["code"]).font = font_normal()
        ws.cell(row=row, column=1).border = THIN_BORDER
        ws.cell(row=row, column=2, value=", ".join(rf["cycles_concernes"])).font = font_normal()
        ws.cell(row=row, column=2).border = THIN_BORDER
        ws.cell(row=row, column=3, value=", ".join(rf["assertions"])).font = font_normal()
        ws.cell(row=row, column=3).border = THIN_BORDER
        ws.cell(row=row, column=4, value=rf["intitule"]).font = font_normal()
        ws.cell(row=row, column=4).border = THIN_BORDER

        niveau = rf["niveau_inherent_defaut"]
        c_niv = ws.cell(row=row, column=6, value=niveau)
        c_niv.font = font_risk(niveau)
        c_niv.fill = fill_risk(niveau)
        c_niv.border = THIN_BORDER
        c_niv.alignment = align_center()

        ws.cell(row=row, column=7, value=rf["reponse_audit_type"]).font = font_small()
        ws.cell(row=row, column=7).border = THIN_BORDER
        row += 1

    for col_letter, width in [("A", 8), ("B", 12), ("C", 10), ("D", 40), ("E", 45), ("F", 14), ("G", 45)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_controles(wb):
    ws = wb.create_sheet("Ref_Controles")
    ws.sheet_properties.tabColor = COLORS["orange"]

    headers = ["Code", "Cycle", "Intitule", "Type", "Frequence", "Objectif", "Assertions couvertes"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    controles = data_loader.load_controles()["controles_cles"]
    for j, ctrl in enumerate(controles):
        r = j + 2
        ws.cell(row=r, column=1, value=ctrl["code"]).font = font_normal()
        ws.cell(row=r, column=1).border = THIN_BORDER
        ws.cell(row=r, column=2, value=ctrl["cycle"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=3, value=ctrl["intitule"]).font = font_normal()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()
        ws.cell(row=r, column=4, value=ctrl["type"]).font = font_normal()
        ws.cell(row=r, column=4).border = THIN_BORDER
        ws.cell(row=r, column=5, value=ctrl["frequence"]).font = font_normal()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=6, value=ctrl["objectif"]).font = font_small()
        ws.cell(row=r, column=6).border = THIN_BORDER
        ws.cell(row=r, column=6).alignment = align_wrap()
        ws.cell(row=r, column=7, value=", ".join(ctrl["assertions_couvertes"])).font = font_normal()
        ws.cell(row=r, column=7).border = THIN_BORDER

    for col_letter, width in [("A", 8), ("B", 10), ("C", 40), ("D", 10), ("E", 12), ("F", 50), ("G", 20)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_profils(wb):
    ws = wb.create_sheet("Ref_Profils")
    ws.sheet_properties.tabColor = COLORS["vert"]

    headers = ["Code", "Nom", "Description", "Cycles actifs", "Risques specifiques", "Controles specifiques"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    profils = data_loader.load_profils()
    for j, profil in enumerate(profils):
        r = j + 2
        ws.cell(row=r, column=1, value=profil["code"]).font = font_normal()
        ws.cell(row=r, column=1).border = THIN_BORDER
        ws.cell(row=r, column=2, value=profil["nom"]).font = font_normal()
        ws.cell(row=r, column=2).border = THIN_BORDER
        ws.cell(row=r, column=3, value=profil["description"]).font = font_small()
        ws.cell(row=r, column=3).border = THIN_BORDER
        ws.cell(row=r, column=3).alignment = align_wrap()
        ws.cell(row=r, column=4, value=", ".join(profil["cycles_actifs"])).font = font_small()
        ws.cell(row=r, column=4).border = THIN_BORDER

        risques = [r_s["intitule"] for r_s in profil.get("risques_specifiques", [])]
        ws.cell(row=r, column=5, value="\n".join(risques)).font = font_small()
        ws.cell(row=r, column=5).border = THIN_BORDER
        ws.cell(row=r, column=5).alignment = align_wrap()

        controles = profil.get("controles_cles_specifiques", [])
        ws.cell(row=r, column=6, value=", ".join(controles)).font = font_small()
        ws.cell(row=r, column=6).border = THIN_BORDER
        ws.cell(row=r, column=6).alignment = align_wrap()

    for col_letter, width in [("A", 12), ("B", 30), ("C", 50), ("D", 40), ("E", 50), ("F", 40)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_programmes(wb):
    ws = wb.create_sheet("Ref_Programmes")
    ws.sheet_properties.tabColor = COLORS["vert"]

    headers = ["Code", "Cycle", "Intitule", "Nature", "Assertions", "Risque min", "Description"]
    for i, h in enumerate(headers):
        c = ws.cell(row=1, column=i + 1, value=h)
        c.font = font_header()
        c.fill = fill_header()
        c.alignment = align_center()
        c.border = THIN_BORDER

    programmes = data_loader.load_programmes()
    row = 2
    for prog in programmes["programmes"]:
        for proc in prog["procedures"]:
            ws.cell(row=row, column=1, value=proc["code"]).font = font_normal()
            ws.cell(row=row, column=1).border = THIN_BORDER
            ws.cell(row=row, column=2, value=prog["cycle"]).font = font_normal()
            ws.cell(row=row, column=2).border = THIN_BORDER
            ws.cell(row=row, column=3, value=proc["intitule"]).font = font_normal()
            ws.cell(row=row, column=3).border = THIN_BORDER
            ws.cell(row=row, column=3).alignment = align_wrap()
            ws.cell(row=row, column=4, value=proc["nature"]).font = font_normal()
            ws.cell(row=row, column=4).border = THIN_BORDER
            ws.cell(row=row, column=5, value=", ".join(proc["assertions"])).font = font_normal()
            ws.cell(row=row, column=5).border = THIN_BORDER
            ws.cell(row=row, column=6, value=proc["niveau_risque_min"]).font = font_normal()
            ws.cell(row=row, column=6).border = THIN_BORDER
            ws.cell(row=row, column=7, value=proc["description"]).font = font_small()
            ws.cell(row=row, column=7).border = THIN_BORDER
            ws.cell(row=row, column=7).alignment = align_wrap()
            row += 1

    for col_letter, width in [("A", 10), ("B", 10), ("C", 45), ("D", 12), ("E", 18), ("F", 12), ("G", 55)]:
        ws.column_dimensions[col_letter].width = width


def _create_ref_seuils(wb):
    ws = wb.create_sheet("Ref_Seuils")
    ws.sheet_properties.tabColor = COLORS["bleu_moyen"]

    seuils = data_loader.load_seuils()

    row = 1
    for profil_key, profil_label in [
        ("societe_commerciale", "Societe commerciale"),
        ("association", "Association"),
        ("cooperative", "Cooperative"),
    ]:
        write_section_title(ws, row, 1, profil_label, 5)
        row += 1

        headers = ["Agregat", "Taux bas", "Taux haut", "Taux defaut", "Commentaire"]
        for i, h in enumerate(headers):
            c = ws.cell(row=row, column=i + 1, value=h)
            c.font = font_header()
            c.fill = fill_header()
            c.alignment = align_center()
            c.border = THIN_BORDER

        row += 1
        for methode in seuils["methodes_calcul"].get(profil_key, []):
            ws.cell(row=row, column=1, value=methode["agregat"]).font = font_normal()
            ws.cell(row=row, column=1).border = THIN_BORDER
            ws.cell(row=row, column=2, value=f"{methode['fourchette_basse_pct']}%").font = font_normal()
            ws.cell(row=row, column=2).border = THIN_BORDER
            ws.cell(row=row, column=3, value=f"{methode['fourchette_haute_pct']}%").font = font_normal()
            ws.cell(row=row, column=3).border = THIN_BORDER
            ws.cell(row=row, column=4, value=f"{methode['defaut_pct']}%").font = font_normal()
            ws.cell(row=row, column=4).border = THIN_BORDER
            ws.cell(row=row, column=5, value=methode["commentaire"]).font = font_small()
            ws.cell(row=row, column=5).border = THIN_BORDER
            row += 1

        row += 1

    write_section_title(ws, row, 1, "Ratios derives", 5)
    row += 1
    for ratio_key, ratio_label in [("seuil_planification", "Seuil de planification"), ("seuil_remontee", "Seuil de remontee")]:
        ratio = seuils["ratios_derives"][ratio_key]
        ws.cell(row=row, column=1, value=ratio_label).font = font_subheader()
        ws.cell(row=row, column=1).border = THIN_BORDER
        ws.cell(row=row, column=2, value=f"{ratio['fourchette_basse']*100}%").border = THIN_BORDER
        ws.cell(row=row, column=3, value=f"{ratio['fourchette_haute']*100}%").border = THIN_BORDER
        ws.cell(row=row, column=4, value=f"{ratio['ratio_defaut']*100}%").border = THIN_BORDER
        ws.cell(row=row, column=5, value=ratio["commentaire"]).font = font_small()
        ws.cell(row=row, column=5).border = THIN_BORDER
        row += 1

    for col_letter, width in [("A", 35), ("B", 12), ("C", 12), ("D", 12), ("E", 55)]:
        ws.column_dimensions[col_letter].width = width


if __name__ == "__main__":
    generate_parametres_cabinet()
