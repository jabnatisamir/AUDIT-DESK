"""Styles and color definitions for the audit workbook."""

from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, NamedStyle
)


COLORS = {
    "bleu_fonce": "1F3864",
    "bleu_moyen": "2E75B6",
    "bleu_clair": "D6E4F0",
    "gris_fonce": "404040",
    "gris_moyen": "808080",
    "gris_clair": "F2F2F2",
    "vert": "548235",
    "vert_clair": "E2EFDA",
    "orange": "ED7D31",
    "orange_clair": "FCE4D6",
    "rouge": "C00000",
    "rouge_clair": "FBE5D6",
    "jaune": "FFC000",
    "jaune_clair": "FFF2CC",
    "blanc": "FFFFFF",
    "noir": "000000",
}

RISK_COLORS = {
    "Faible": "E2EFDA",
    "Modere": "FFF2CC",
    "Eleve": "FCE4D6",
    "Significatif": "FBE5D6",
}

RISK_FONT_COLORS = {
    "Faible": "548235",
    "Modere": "BF8F00",
    "Eleve": "ED7D31",
    "Significatif": "C00000",
}

STATUS_COLORS = {
    "Non demarre": "F2F2F2",
    "En cours": "FFF2CC",
    "Termine - a revoir": "FCE4D6",
    "Revue manager": "D6E4F0",
    "Revue associe": "D6E4F0",
    "Valide": "E2EFDA",
    "Cloture": "E2EFDA",
}

THIN_BORDER = Border(
    left=Side(style="thin", color=COLORS["gris_moyen"]),
    right=Side(style="thin", color=COLORS["gris_moyen"]),
    top=Side(style="thin", color=COLORS["gris_moyen"]),
    bottom=Side(style="thin", color=COLORS["gris_moyen"]),
)

HEADER_BORDER = Border(
    left=Side(style="thin", color=COLORS["blanc"]),
    right=Side(style="thin", color=COLORS["blanc"]),
    top=Side(style="thin", color=COLORS["blanc"]),
    bottom=Side(style="medium", color=COLORS["blanc"]),
)


def font_header():
    return Font(name="Calibri", size=11, bold=True, color=COLORS["blanc"])


def font_subheader():
    return Font(name="Calibri", size=10, bold=True, color=COLORS["bleu_fonce"])


def font_normal():
    return Font(name="Calibri", size=10, color=COLORS["noir"])


def font_small():
    return Font(name="Calibri", size=9, color=COLORS["gris_fonce"])


def fill_header():
    return PatternFill(start_color=COLORS["bleu_fonce"], end_color=COLORS["bleu_fonce"], fill_type="solid")


def fill_subheader():
    return PatternFill(start_color=COLORS["bleu_clair"], end_color=COLORS["bleu_clair"], fill_type="solid")


def fill_input():
    return PatternFill(start_color=COLORS["jaune_clair"], end_color=COLORS["jaune_clair"], fill_type="solid")


def fill_calculated():
    return PatternFill(start_color=COLORS["gris_clair"], end_color=COLORS["gris_clair"], fill_type="solid")


def fill_risk(niveau):
    color = RISK_COLORS.get(niveau, COLORS["blanc"])
    return PatternFill(start_color=color, end_color=color, fill_type="solid")


def font_risk(niveau):
    color = RISK_FONT_COLORS.get(niveau, COLORS["noir"])
    return Font(name="Calibri", size=10, bold=True, color=color)


def align_center():
    return Alignment(horizontal="center", vertical="center", wrap_text=True)


def align_left():
    return Alignment(horizontal="left", vertical="center", wrap_text=True)


def align_wrap():
    return Alignment(horizontal="left", vertical="top", wrap_text=True)


def apply_header_row(ws, row, col_start, col_end):
    for col in range(col_start, col_end + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = font_header()
        cell.fill = fill_header()
        cell.alignment = align_center()
        cell.border = HEADER_BORDER


def apply_data_row(ws, row, col_start, col_end, is_input=False):
    for col in range(col_start, col_end + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = font_normal()
        cell.alignment = align_left()
        cell.border = THIN_BORDER
        if is_input:
            cell.fill = fill_input()


def write_section_title(ws, row, col, title, merge_end_col=None):
    cell = ws.cell(row=row, column=col, value=title)
    cell.font = font_subheader()
    cell.fill = fill_subheader()
    cell.alignment = align_left()
    if merge_end_col:
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=merge_end_col)
        for c in range(col, merge_end_col + 1):
            ws.cell(row=row, column=c).fill = fill_subheader()
            ws.cell(row=row, column=c).border = THIN_BORDER
