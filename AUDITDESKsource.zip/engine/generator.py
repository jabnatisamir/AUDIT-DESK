"""Main workbook generator — assembles all sheets into the audit dossier."""

import os
from openpyxl import Workbook

from engine import data_loader
from engine.sheets.accueil import create_accueil
from engine.sheets.acceptation import create_acceptation, create_prise_connaissance
from engine.sheets.seuils import create_seuils
from engine.sheets.matrice_risques import create_matrice_risques
from engine.sheets.controle_interne import create_controle_interne, create_itgc, create_itac
from engine.sheets.cycle_travail import create_cycle_sheet
from engine.sheets.synthese import (
    create_feuilles_maitresses,
    create_anomalies,
    create_synthese_generale,
    create_points_revue,
    create_finalisation,
)
from engine.sheets.gestion_cabinet import (
    create_temps,
    create_rentabilite,
    create_dashboard,
)


def generate_dossier(profil_code="SOC_COM", output_path=None):
    """Generate a complete audit dossier workbook.

    Args:
        profil_code: Entity profile code (SOC_COM, HOLDING, ASSO, ESS, SPECTACLE, COOP)
        output_path: Output file path. Defaults to output/Dossier_Audit_{profil_code}.xlsx
    """
    if output_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(base_dir, "output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, f"Dossier_Audit_{profil_code}.xlsx")

    mission_data = data_loader.load_mission_template()
    mission_data["mission"]["entite"]["profil_entite"] = profil_code

    seuils_ref = data_loader.load_seuils()

    wb = Workbook()

    # A. Pilotage
    print(f"[1/12] Accueil...")
    create_accueil(wb, mission_data)

    print(f"[2/12] Dashboard...")
    create_dashboard(wb, profil_code)

    # B. Approche
    print(f"[3/12] Acceptation / Maintien...")
    create_acceptation(wb)

    print(f"[4/12] Prise de connaissance...")
    create_prise_connaissance(wb, profil_code)

    print(f"[5/12] Seuils...")
    create_seuils(wb, mission_data, seuils_ref)

    print(f"[6/12] Matrice des risques...")
    create_matrice_risques(wb, mission_data, profil_code)

    # C. Controle interne / SI
    print(f"[7/12] Controle interne / ITGC / ITAC...")
    create_controle_interne(wb, profil_code)
    create_itgc(wb)
    create_itac(wb)

    # D. Cycles
    cycles = data_loader.get_cycles_for_profil(profil_code)
    print(f"[8/12] Feuilles de travail ({len(cycles)} cycles)...")
    for cycle in cycles:
        create_cycle_sheet(wb, cycle, profil_code)

    # E. Finalisation
    print(f"[9/12] Feuilles maitresses...")
    create_feuilles_maitresses(wb, profil_code)

    print(f"[10/12] Anomalies + Synthese + Revue + Finalisation...")
    create_anomalies(wb)
    create_synthese_generale(wb, profil_code)
    create_points_revue(wb)
    create_finalisation(wb)

    # F. Gestion cabinet
    print(f"[11/12] Temps + Rentabilite...")
    create_temps(wb, mission_data)
    create_rentabilite(wb, mission_data)

    # Save
    print(f"[12/12] Enregistrement -> {output_path}")
    wb.save(output_path)
    print(f"Dossier genere avec succes: {output_path}")
    print(f"  Profil: {profil_code}")
    print(f"  Onglets: {len(wb.sheetnames)}")
    print(f"  Cycles: {len(cycles)}")

    return output_path


def generate_all_profils(output_dir=None):
    """Generate dossiers for all entity profiles."""
    if output_dir is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(base_dir, "output")

    profils = data_loader.load_profils()
    paths = []
    for profil in profils:
        code = profil["code"]
        print(f"\n{'='*60}")
        print(f"Generation du dossier: {profil['nom']} ({code})")
        print(f"{'='*60}")
        path = generate_dossier(
            profil_code=code,
            output_path=os.path.join(output_dir, f"Dossier_Audit_{code}.xlsx")
        )
        paths.append(path)

    print(f"\n{'='*60}")
    print(f"{len(paths)} dossiers generes dans {output_dir}")
    return paths
